import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'dashboard_screen.dart';

import 'core/theme/app_theme.dart';
import 'services/supabase_service.dart';

class MobileLoginScreen extends StatefulWidget {
  const MobileLoginScreen({super.key, required this.service});

  final SupabaseService service;

  @override
  State<MobileLoginScreen> createState() => _MobileLoginScreenState();
}

class _MobileLoginScreenState extends State<MobileLoginScreen> {
  // Paste your Web client ID here if you want to avoid --dart-define.
  static const String _hardcodedGoogleWebClientId =
      '868115796278-2eat2lpirmfvt0gd60sf6ejo8kkcmjcp.apps.googleusercontent.com';
    static final String _googleWebClientId =
      _hardcodedGoogleWebClientId.isNotEmpty
      ? _hardcodedGoogleWebClientId
      : const String.fromEnvironment('GOOGLE_WEB_CLIENT_ID');

  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();
  final GoogleSignIn _googleSignIn = GoogleSignIn(
    scopes: <String>['email', 'openid', 'profile'],
    serverClientId: _googleWebClientId.isEmpty ? null : _googleWebClientId,
  );

  bool _isPasswordVisible = false;
  bool _isLoading = false;
  bool _isSignUpMode = false;

  @override
  void dispose() {
    _emailController.dispose();
    _passwordController.dispose();
    super.dispose();
  }

  bool _isAdduEmail(String email) {
    return email.toLowerCase().endsWith('@addu.edu.ph');
  }

  Future<void> _handleAuthAction() async {
    final email = _emailController.text.trim();
    final password = _passwordController.text.trim();

    if (email.isEmpty || password.isEmpty) {
      _showSnack('Please enter both your AdDU email and password.');
      return;
    }

    if (!_isAdduEmail(email)) {
      _showSnack('Use your @addu.edu.ph email to continue.');
      return;
    }

    setState(() => _isLoading = true);

    try {
      if (_isSignUpMode) {
        await widget.service.signUpWithEmail(email: email, password: password);
        if (mounted) {
          _showSnack(
            'Account created. Check your inbox if email confirmation is enabled, then sign in.',
          );
        }
      } else {
        await widget.service.signInWithEmail(email: email, password: password);
        _openDashboard(isGuest: false);
      }
    } catch (error) {
      _showSnack('Authentication failed: $error');
    } finally {
      if (mounted) {
        setState(() => _isLoading = false);
      }
    }
  }

  Future<void> _signInWithGoogle() async {
    setState(() => _isLoading = true);

    try {
      if (_googleWebClientId.isEmpty) {
        _showSnack(
          'Missing Google Web Client ID. Set _hardcodedGoogleWebClientId in mobile_login_screen.dart or run with --dart-define=GOOGLE_WEB_CLIENT_ID=<web-client-id>.apps.googleusercontent.com',
        );
        return;
      }

      await _googleSignIn.signOut();
      final googleUser = await _googleSignIn.signIn();

      if (googleUser == null) {
        return;
      }

      if (!_isAdduEmail(googleUser.email)) {
        await _googleSignIn.signOut();
        _showSnack('Please sign in using your AdDU Google account.');
        return;
      }

      final googleAuth = await googleUser.authentication;
      final idToken = googleAuth.idToken;

      if (idToken == null || idToken.isEmpty) {
        _showSnack('Google sign-in failed. No id token returned.');
        return;
      }

      await widget.service.signInWithGoogleTokens(
        idToken: idToken,
        accessToken: googleAuth.accessToken,
      );

      _openDashboard(isGuest: false);
    } on PlatformException catch (error) {
      final details = [
        if (error.message != null && error.message!.isNotEmpty) error.message!,
        if (error.details != null) error.details.toString(),
      ].join(' | ');
      _showSnack(
        'Google Sign-In failed (${error.code})${details.isNotEmpty ? ': $details' : ''}. Check Android OAuth package/SHA-1 config.',
      );
    } catch (error) {
      _showSnack('Google Sign-In Error: $error');
    } finally {
      if (mounted) {
        setState(() => _isLoading = false);
      }
    }
  }

  void _showSnack(String message) {
    if (!mounted) {
      return;
    }
    ScaffoldMessenger.of(
      context,
    ).showSnackBar(SnackBar(content: Text(message)));
  }

  void _openDashboard({required bool isGuest}) {
    if (!mounted) {
      return;
    }
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(
        builder: (context) =>
            DashboardScreen(service: widget.service, isGuest: isGuest),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(24),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Container(
                  width: 90,
                  height: 90,
                  decoration: const BoxDecoration(
                    color: AppColors.ateneoBlueMain,
                    shape: BoxShape.circle,
                  ),
                  child: const Icon(
                    Icons.school_rounded,
                    size: 48,
                    color: AppColors.ateneoYellowMain,
                  ),
                ),
                const SizedBox(height: 20),
                const Text(
                  'AdDU Scholarship Manager',
                  style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold),
                  textAlign: TextAlign.center,
                ),
                const SizedBox(height: 8),
                Text(
                  _isSignUpMode
                      ? 'Create your student account'
                      : 'Track applications and scholarship updates in one place.',
                  style: Theme.of(
                    context,
                  ).textTheme.bodyMedium?.copyWith(color: AppColors.mutedText),
                  textAlign: TextAlign.center,
                ),
                const SizedBox(height: 40),

                TextField(
                  controller: _emailController,
                  keyboardType: TextInputType.emailAddress,
                  decoration: InputDecoration(
                    prefixIcon: const Icon(Icons.email_outlined),
                    labelText: 'AdDU Email',
                    hintText: 'name@addu.edu.ph',
                  ),
                ),
                const SizedBox(height: 16),

                TextField(
                  controller: _passwordController,
                  obscureText: !_isPasswordVisible,
                  decoration: InputDecoration(
                    prefixIcon: const Icon(Icons.lock_outline),
                    labelText: 'Password',
                    suffixIcon: IconButton(
                      icon: Icon(
                        _isPasswordVisible
                            ? Icons.visibility
                            : Icons.visibility_off,
                      ),
                      onPressed: () {
                        setState(() {
                          _isPasswordVisible = !_isPasswordVisible;
                        });
                      },
                    ),
                  ),
                ),
                const SizedBox(height: 24),

                ElevatedButton(
                  onPressed: _isLoading ? null : _handleAuthAction,
                  child: _isLoading
                      ? const SizedBox(
                          height: 24,
                          width: 24,
                          child: CircularProgressIndicator(
                            strokeWidth: 2.4,
                            color: Colors.white,
                          ),
                        )
                      : Text(
                          _isSignUpMode ? 'Create Account' : 'Sign In',
                          style: const TextStyle(fontSize: 17),
                        ),
                ),
                const SizedBox(height: 14),
                TextButton(
                  onPressed: _isLoading
                      ? null
                      : () {
                          setState(() {
                            _isSignUpMode = !_isSignUpMode;
                          });
                        },
                  child: Text(
                    _isSignUpMode
                        ? 'Already have an account? Sign In'
                        : 'Need an account? Sign Up',
                  ),
                ),
                const SizedBox(height: 24),

                Row(
                  children: [
                    Expanded(
                      child: Divider(
                        color: AppColors.ateneoBlueMain.withValues(alpha: 0.28),
                      ),
                    ),
                    const Padding(
                      padding: EdgeInsets.symmetric(horizontal: 12),
                      child: Text('OR'),
                    ),
                    Expanded(
                      child: Divider(
                        color: AppColors.ateneoBlueMain.withValues(alpha: 0.28),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 24),

                OutlinedButton.icon(
                  onPressed: _isLoading ? null : _signInWithGoogle,
                  icon: const Icon(
                    Icons.g_mobiledata,
                    color: Colors.red,
                    size: 32,
                  ),
                  label: const Text('Sign in with AdDU Google'),
                ),
                const SizedBox(height: 12),

                TextButton(
                  onPressed: () {
                    _openDashboard(isGuest: true);
                  },
                  child: const Text(
                    'Continue as Guest (Read-only)',
                    style: TextStyle(fontSize: 14),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
