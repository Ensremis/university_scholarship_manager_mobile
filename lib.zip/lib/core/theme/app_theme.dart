import 'package:flutter/material.dart';

class AppColors {
  static const Color ateneoBlueMain = Color(0xFF2F3590);
  static const Color ateneoBlue2 = Color(0xFF1611B1);
  static const Color ateneoBlue3 = Color(0xFF040354);

  static const Color ateneoYellowMain = Color(0xFFFDF036);
  static const Color ateneoYellow2 = Color(0xFFFFD858);
  static const Color ateneoYellow3 = Color(0xFFFCCA27);

  static const Color surface = Color(0xFFF6F7FB);
  static const Color card = Colors.white;
  static const Color mutedText = Color(0xFF5F6475);
}

class AppTheme {
  static ThemeData lightTheme() {
    final colorScheme = ColorScheme.fromSeed(
      seedColor: AppColors.ateneoBlueMain,
      brightness: Brightness.light,
      primary: AppColors.ateneoBlueMain,
      secondary: AppColors.ateneoYellow3,
      surface: AppColors.surface,
    );

    const String headingFont = 'Avenir';
    const String bodyFont = 'Open Sans';

    final base = ThemeData(
      useMaterial3: true,
      colorScheme: colorScheme,
      scaffoldBackgroundColor: AppColors.surface,
      fontFamily: bodyFont,
    );

    return base.copyWith(
      textTheme: base.textTheme.copyWith(
        displayLarge: base.textTheme.displayLarge?.copyWith(
          fontFamily: headingFont,
          fontWeight: FontWeight.w700,
          color: AppColors.ateneoBlue3,
        ),
        displayMedium: base.textTheme.displayMedium?.copyWith(
          fontFamily: headingFont,
          fontWeight: FontWeight.w700,
          color: AppColors.ateneoBlue3,
        ),
        headlineMedium: base.textTheme.headlineMedium?.copyWith(
          fontFamily: headingFont,
          fontWeight: FontWeight.w700,
          color: AppColors.ateneoBlue3,
        ),
        titleLarge: base.textTheme.titleLarge?.copyWith(
          fontFamily: headingFont,
          fontWeight: FontWeight.w700,
          color: AppColors.ateneoBlue3,
        ),
        titleMedium: base.textTheme.titleMedium?.copyWith(
          fontWeight: FontWeight.w600,
          color: AppColors.ateneoBlue3,
        ),
        bodyLarge: base.textTheme.bodyLarge?.copyWith(
          color: AppColors.ateneoBlue3,
          fontFamily: bodyFont,
        ),
        bodyMedium: base.textTheme.bodyMedium?.copyWith(
          color: AppColors.ateneoBlue3,
          fontFamily: bodyFont,
        ),
        bodySmall: base.textTheme.bodySmall?.copyWith(
          color: AppColors.mutedText,
          fontFamily: bodyFont,
        ),
      ),
      appBarTheme: const AppBarTheme(
        backgroundColor: AppColors.ateneoBlueMain,
        foregroundColor: Colors.white,
        elevation: 0,
        centerTitle: true,
      ),
      cardTheme: CardThemeData(
        color: AppColors.card,
        elevation: 0.7,
        margin: EdgeInsets.zero,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
      ),
      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: Colors.white,
        contentPadding: const EdgeInsets.symmetric(
          horizontal: 16,
          vertical: 14,
        ),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: BorderSide(
            color: AppColors.ateneoBlueMain.withValues(alpha: 0.22),
          ),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: BorderSide(
            color: AppColors.ateneoBlueMain.withValues(alpha: 0.22),
          ),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: const BorderSide(
            color: AppColors.ateneoBlue2,
            width: 1.4,
          ),
        ),
      ),
      elevatedButtonTheme: ElevatedButtonThemeData(
        style: ElevatedButton.styleFrom(
          backgroundColor: AppColors.ateneoBlueMain,
          foregroundColor: Colors.white,
          minimumSize: const Size(double.infinity, 52),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(14),
          ),
        ),
      ),
      chipTheme: base.chipTheme.copyWith(
        side: BorderSide.none,
        selectedColor: AppColors.ateneoYellow2,
        backgroundColor: AppColors.ateneoYellowMain.withValues(alpha: 0.32),
      ),
    );
  }
}
