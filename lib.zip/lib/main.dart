import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'core/theme/app_theme.dart';
import 'mobile_login_screen.dart';
import 'services/supabase_service.dart';

// Edrian Nino S. Remis
Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  await Supabase.initialize(
    url: 'https://awcjmqsnajfqraeerxvi.supabase.co',
    anonKey:
        'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImF3Y2ptcXNuYWpmcXJhZWVyeHZpIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzQ2ODExMDAsImV4cCI6MjA5MDI1NzEwMH0.N75hQdCJcKkBK7vZsVVTXv_l0jnZHcRpnGIBX_jvFow',
  );

  runApp(const SchoolApp());
}

class SchoolApp extends StatelessWidget {
  const SchoolApp({super.key});

  @override
  Widget build(BuildContext context) {
    final supabaseService = SupabaseService(Supabase.instance.client);

    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: AppTheme.lightTheme(),
      home: MobileLoginScreen(service: supabaseService),
    );
  }
}
