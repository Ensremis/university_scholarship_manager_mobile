import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import 'core/theme/app_theme.dart';
import 'mobile_login_screen.dart';
import 'models/announcement.dart';
import 'models/editable_application_entry.dart';
import 'models/scholarship.dart';
import 'services/supabase_service.dart';

class DashboardScreen extends StatefulWidget {
  const DashboardScreen({
    super.key,
    required this.service,
    required this.isGuest,
  });

  final SupabaseService service;
  final bool isGuest;

  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  int _currentTab = 0;

  String get _userEmail => widget.service.currentUser?.email ?? 'Guest User';

  Future<void> _submitApplication(Scholarship scholarship) async {
    final user = widget.service.currentUser;
    if (user == null) {
      _showSnack('Sign in first to submit applications.');
      return;
    }

    final notesController = TextEditingController();
    final imagePicker = ImagePicker();
    List<XFile> selectedPhotos = [];

    final shouldSubmit =
        await showDialog<bool>(
          context: context,
          builder: (context) => AlertDialog(
            title: Text('Apply: ${scholarship.title}'),
            content: StatefulBuilder(
              builder: (context, setDialogState) => Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  TextField(
                    controller: notesController,
                    maxLines: 4,
                    decoration: const InputDecoration(
                      hintText: 'Optional note for your application',
                      labelText: 'Notes',
                    ),
                  ),
                  const SizedBox(height: 14),
                  OutlinedButton.icon(
                    onPressed: () async {
                      try {
                        final picked = await imagePicker.pickMultiImage(
                          imageQuality: 85,
                          maxWidth: 2000,
                        );

                        if (picked.isNotEmpty) {
                          setDialogState(() => selectedPhotos = picked);
                        }
                      } catch (_) {
                        if (context.mounted) {
                          ScaffoldMessenger.of(context).showSnackBar(
                            const SnackBar(
                              content: Text(
                                'Could not open gallery. Check app permissions.',
                              ),
                            ),
                          );
                        }
                      }
                    },
                    icon: const Icon(Icons.photo_library_rounded),
                    label: const Text('Upload images'),
                  ),
                  if (selectedPhotos.isNotEmpty)
                    Padding(
                      padding: const EdgeInsets.only(top: 8),
                      child: Text(
                        'Selected ${selectedPhotos.length} image(s)',
                        style: Theme.of(context).textTheme.bodySmall,
                      ),
                    ),
                ],
              ),
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(context, false),
                child: const Text('Cancel'),
              ),
              ElevatedButton(
                onPressed: () => Navigator.pop(context, true),
                child: const Text('Submit'),
              ),
            ],
          ),
        ) ??
        false;

    if (!shouldSubmit) {
      return;
    }

    try {
      final alreadyApplied = await widget.service.hasSubmittedApplication(
        userId: user.id,
        scholarshipId: scholarship.id,
      );
      if (alreadyApplied) {
        _showSnack('You already submitted this scholarship application.');
        return;
      }

      final List<String> documentRefs = [];
      for (final photo in selectedPhotos) {
        final photoBytes = await photo.readAsBytes();
        final documentRef = await widget.service.uploadApplicationPhoto(
          userId: user.id,
          scholarshipId: scholarship.id,
          fileBytes: photoBytes,
          fileName: photo.name,
        );
        documentRefs.add(documentRef);
      }

      await widget.service.submitApplication(
        userId: user.id,
        scholarshipId: scholarship.id,
        notes: notesController.text.trim(),
        documentRefs: documentRefs,
      );
      if (mounted) {
        _showSnack(
          documentRefs.isEmpty
              ? 'Application submitted successfully.'
              : 'Application and images submitted successfully.',
        );
        setState(() => _currentTab = 1);
      }
    } catch (error) {
      if (error is StorageException) {
        _showSnack(
          'Upload blocked by Supabase Storage policy (403). Run the requirements bucket RLS policy SQL, then try again.',
        );
        return;
      }

      if (error is PostgrestException && error.code == '23505') {
        _showSnack('You already submitted this scholarship application.');
        return;
      }

      _showSnack('Could not submit application: $error');
    }
  }

  Future<void> _signOut() async {
    try {
      if (!widget.isGuest) {
        await widget.service.signOut();
      }
      if (mounted) {
        Navigator.pushAndRemoveUntil(
          context,
          MaterialPageRoute(
            builder: (context) => MobileLoginScreen(service: widget.service),
          ),
          (route) => false,
        );
      }
    } catch (error) {
      _showSnack('Could not sign out: $error');
    }
  }

  void _showSnack(String message) {
    if (!mounted) {
      return;
    }
    ScaffoldMessenger.of(
      context,
    ).showSnackBar(SnackBar(content: Text(message)));
  }

  @override
  Widget build(BuildContext context) {
    const tabTitles = [
      'Scholarships',
      'My Applications',
      'Announcements',
      'Profile',
    ];

    return Scaffold(
      appBar: AppBar(
        title: Text(tabTitles[_currentTab]),
        actions: [
          IconButton(
            tooltip: 'Sign Out',
            onPressed: _signOut,
            icon: const Icon(Icons.logout_rounded),
          ),
        ],
      ),
      body: IndexedStack(
        index: _currentTab,
        children: [
          _ScholarshipsTab(
            service: widget.service,
            isGuest: widget.isGuest,
            onApply: _submitApplication,
          ),
          _ApplicationsTab(service: widget.service, isGuest: widget.isGuest),
          _AnnouncementsTab(service: widget.service),
          _ProfileTab(
            email: _userEmail,
            isGuest: widget.isGuest,
            onSignOut: _signOut,
          ),
        ],
      ),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _currentTab,
        onDestinationSelected: (index) {
          setState(() => _currentTab = index);
        },
        destinations: const [
          NavigationDestination(
            icon: Icon(Icons.school_outlined),
            selectedIcon: Icon(Icons.school_rounded),
            label: 'Scholarships',
          ),
          NavigationDestination(
            icon: Icon(Icons.assignment_outlined),
            selectedIcon: Icon(Icons.assignment_turned_in_rounded),
            label: 'Applications',
          ),
          NavigationDestination(
            icon: Icon(Icons.campaign_outlined),
            selectedIcon: Icon(Icons.campaign_rounded),
            label: 'Updates',
          ),
          NavigationDestination(
            icon: Icon(Icons.person_outline_rounded),
            selectedIcon: Icon(Icons.person_rounded),
            label: 'Profile',
          ),
        ],
      ),
    );
  }
}

class _ScholarshipsTab extends StatelessWidget {
  const _ScholarshipsTab({
    required this.service,
    required this.isGuest,
    required this.onApply,
  });

  final SupabaseService service;
  final bool isGuest;
  final Future<void> Function(Scholarship scholarship) onApply;

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<List<Scholarship>>(
      future: service.fetchScholarships(),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Center(child: CircularProgressIndicator());
        }

        if (snapshot.hasError) {
          return _ErrorState(
            message:
                'Could not load scholarships. Ensure your table exists and has data.',
          );
        }

        final items = snapshot.data ?? const [];
        if (items.isEmpty) {
          return const _EmptyState(
            title: 'No scholarships yet',
            subtitle:
                'Once records are added in Supabase, they will appear here.',
          );
        }

        return ListView.separated(
          padding: const EdgeInsets.all(16),
          itemCount: items.length,
          separatorBuilder: (_, index) => const SizedBox(height: 14),
          itemBuilder: (context, index) {
            final scholarship = items[index];
            return Card(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Expanded(
                          child: Text(
                            scholarship.title,
                            style: Theme.of(context).textTheme.titleLarge,
                          ),
                        ),
                        Container(
                          padding: const EdgeInsets.symmetric(
                            horizontal: 10,
                            vertical: 6,
                          ),
                          decoration: BoxDecoration(
                            color: scholarship.isOpen
                                ? AppColors.ateneoYellow2
                                : Colors.grey.shade300,
                            borderRadius: BorderRadius.circular(999),
                          ),
                          child: Text(
                            scholarship.isOpen ? 'Open' : 'Closed',
                            style: const TextStyle(fontWeight: FontWeight.w700),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 8),
                    Text(scholarship.description),
                    const SizedBox(height: 12),
                    Text(
                      'Deadline: ${_formatDate(scholarship.deadline)}',
                      style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                        color: AppColors.mutedText,
                      ),
                    ),
                    const SizedBox(height: 10),
                    Wrap(
                      spacing: 8,
                      runSpacing: 8,
                      children: scholarship.requirements
                          .map((item) => Chip(label: Text(item)))
                          .toList(),
                    ),
                    const SizedBox(height: 14),
                    ElevatedButton.icon(
                      onPressed: scholarship.isOpen && !isGuest
                          ? () => onApply(scholarship)
                          : null,
                      icon: const Icon(Icons.send_rounded),
                      label: Text(isGuest ? 'Sign in to apply' : 'Apply now'),
                    ),
                  ],
                ),
              ),
            );
          },
        );
      },
    );
  }
}

class _ApplicationsTab extends StatefulWidget {
  const _ApplicationsTab({required this.service, required this.isGuest});

  final SupabaseService service;
  final bool isGuest;

  @override
  State<_ApplicationsTab> createState() => _ApplicationsTabState();
}

class _ApplicationsTabState extends State<_ApplicationsTab> {
  bool _isLoading = true;
  String? _errorMessage;
  List<EditableApplicationEntry> _entries = [];

  @override
  void initState() {
    super.initState();
    _loadEntries();
  }

  Future<void> _loadEntries() async {
    if (widget.isGuest) {
      setState(() {
        _isLoading = false;
        _errorMessage = null;
        _entries = [];
      });
      return;
    }

    final user = widget.service.currentUser;
    if (user == null) {
      setState(() {
        _isLoading = false;
        _errorMessage = null;
        _entries = [];
      });
      return;
    }

    setState(() {
      _isLoading = true;
      _errorMessage = null;
    });

    try {
      final rows = await widget.service.fetchApplicationsForUser(user.id);
      if (!mounted) {
        return;
      }
      setState(() {
        _entries = rows
            .map(EditableApplicationEntry.fromApplication)
            .toList();
        _isLoading = false;
      });
    } catch (_) {
      if (!mounted) {
        return;
      }
      setState(() {
        _errorMessage =
            'Could not load applications. Check table policies and joins.';
        _isLoading = false;
      });
    }
  }

  void _setExpanded(String applicationId, bool expanded) {
    void applyUpdate() {
      if (!mounted) {
        return;
      }
      setState(() {
        _entries = _entries
            .map(
              (entry) => entry.application.id == applicationId
                  ? entry.copyWith(isExpanded: expanded)
                  : entry,
            )
            .toList();
      });
    }

    WidgetsBinding.instance.addPostFrameCallback((_) {
      applyUpdate();
    });
  }

  Future<void> _editEntry(EditableApplicationEntry entry) async {
    final user = widget.service.currentUser;
    if (user == null) {
      return;
    }

    final notesController = TextEditingController(
      text: entry.application.notes,
    );
    final imagePicker = ImagePicker();
    List<XFile> additionalPhotos = [];

    final shouldSave =
        await showDialog<bool>(
          context: context,
          builder: (context) => AlertDialog(
            title: const Text('Edit application'),
            content: StatefulBuilder(
              builder: (context, setDialogState) => Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  TextField(
                    controller: notesController,
                    maxLines: 4,
                    decoration: const InputDecoration(
                      labelText: 'Notes',
                      hintText: 'Update your note for this application',
                    ),
                  ),
                  const SizedBox(height: 14),
                  OutlinedButton.icon(
                    onPressed: () async {
                      final picked = await imagePicker.pickMultiImage(
                        imageQuality: 85,
                        maxWidth: 2000,
                      );
                      if (picked.isNotEmpty) {
                        setDialogState(() => additionalPhotos = picked);
                      }
                    },
                    icon: const Icon(Icons.photo_library_rounded),
                    label: const Text('Add more images (optional)'),
                  ),
                  if (additionalPhotos.isNotEmpty)
                    Padding(
                      padding: const EdgeInsets.only(top: 8),
                      child: Text(
                        'Selected ${additionalPhotos.length} image(s)',
                      ),
                    ),
                ],
              ),
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(context, false),
                child: const Text('Cancel'),
              ),
              ElevatedButton(
                onPressed: () => Navigator.pop(context, true),
                child: const Text('Save'),
              ),
            ],
          ),
        ) ??
        false;

    if (!shouldSave) {
      return;
    }

    try {
      final mergedDocumentRefs = <String>[...entry.application.documentRefs];
      for (final photo in additionalPhotos) {
        final photoBytes = await photo.readAsBytes();
        final documentRef = await widget.service.uploadApplicationPhoto(
          userId: user.id,
          scholarshipId: entry.application.scholarshipId,
          fileBytes: photoBytes,
          fileName: photo.name,
        );
        mergedDocumentRefs.add(documentRef);
      }

      await widget.service.updateApplicationForUser(
        applicationId: entry.application.id,
        userId: user.id,
        notes: notesController.text.trim(),
        documentRefs: mergedDocumentRefs,
      );

      if (!mounted) {
        return;
      }

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Application updated.')),
      );
      await _loadEntries();
    } catch (error) {
      if (!mounted) {
        return;
      }
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Could not update application: $error')),
      );
    }
  }

  Future<void> _viewDocumentImage(String documentRef) async {
    String imageUrl;
    try {
      imageUrl = await widget.service.buildDocumentAccessUrl(documentRef);
    } catch (error) {
      if (!mounted) {
        return;
      }
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            'Could not open document image (missing file or wrong path): $error',
          ),
        ),
      );
      return;
    }
    if (!mounted) {
      return;
    }

    await showDialog<void>(
      context: context,
      builder: (context) => Dialog(
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Row(
                children: [
                  const Text(
                    'Uploaded Image',
                    style: TextStyle(fontWeight: FontWeight.w700),
                  ),
                  const Spacer(),
                  IconButton(
                    onPressed: () => Navigator.pop(context),
                    icon: const Icon(Icons.close_rounded),
                  ),
                ],
              ),
              const SizedBox(height: 8),
              ConstrainedBox(
                constraints: const BoxConstraints(maxHeight: 420),
                child: InteractiveViewer(
                  minScale: 1,
                  maxScale: 4,
                  child: Image.network(
                    imageUrl,
                    fit: BoxFit.contain,
                    loadingBuilder: (context, child, loadingProgress) {
                      if (loadingProgress == null) {
                        return child;
                      }
                      return const Padding(
                        padding: EdgeInsets.all(24),
                        child: Center(child: CircularProgressIndicator()),
                      );
                    },
                    errorBuilder: (context, error, stackTrace) {
                      return const Padding(
                        padding: EdgeInsets.all(12),
                        child: Text(
                          'Could not load image preview. The file may be missing or not publicly readable.',
                          textAlign: TextAlign.center,
                        ),
                      );
                    },
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    if (widget.isGuest) {
      return const _EmptyState(
        title: 'Guest mode is read-only',
        subtitle:
            'Sign in with your AdDU email to submit and track applications.',
      );
    }

    final user = widget.service.currentUser;
    if (user == null) {
      return const _EmptyState(
        title: 'No active user',
        subtitle: 'Sign in again to view your applications.',
      );
    }

    if (_isLoading) {
      return const Center(child: CircularProgressIndicator());
    }

    if (_errorMessage != null) {
      return _ErrorState(message: _errorMessage!);
    }

    if (_entries.isEmpty) {
      return const _EmptyState(
        title: 'No submitted applications',
        subtitle:
            'Apply to a scholarship and your status tracker will appear here.',
      );
    }

    return RefreshIndicator(
      onRefresh: _loadEntries,
      child: ListView.separated(
        padding: const EdgeInsets.all(16),
        itemCount: _entries.length,
        separatorBuilder: (_, index) => const SizedBox(height: 12),
        itemBuilder: (context, index) {
          final entry = _entries[index];
          final app = entry.application;
          final hasDocument = app.documentRefs.isNotEmpty;

          return Card(
            child: ExpansionTile(
              key: PageStorageKey(app.id),
              initiallyExpanded: entry.isExpanded,
              onExpansionChanged: (expanded) {
                _setExpanded(app.id, expanded);
              },
              tilePadding: const EdgeInsets.symmetric(
                horizontal: 16,
                vertical: 6,
              ),
              title: Text(
                app.scholarshipTitle,
                style: Theme.of(context).textTheme.titleMedium,
              ),
              subtitle: Padding(
                padding: const EdgeInsets.only(top: 6),
                child: Text(
                  'Status: ${app.status.toUpperCase()}\nSubmitted: ${_formatDate(app.submittedAt)}\nDocument(s): ${app.documentRefs.length}',
                ),
              ),
              childrenPadding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
              children: [
                Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Icon(Icons.notes_rounded, size: 18),
                    const SizedBox(width: 8),
                    Expanded(
                      child: Text(
                        app.notes.isEmpty ? 'No notes provided.' : app.notes,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 10),
                Row(
                  children: [
                    const Icon(Icons.link_rounded, size: 18),
                    const SizedBox(width: 8),
                    Expanded(
                      child: Text(
                        hasDocument
                            ? '${app.documentRefs.length} document image(s) saved.'
                            : 'No document images.',
                      ),
                    ),
                  ],
                ),
                if (hasDocument) const SizedBox(height: 10),
                if (hasDocument)
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text(
                        'Uploaded Images',
                        style: TextStyle(fontWeight: FontWeight.w700),
                      ),
                      const SizedBox(height: 8),
                      Wrap(
                        spacing: 8,
                        runSpacing: 8,
                        children: app.documentRefs.map((docRef) {
                          return FutureBuilder<String>(
                            future: widget.service.buildDocumentAccessUrl(
                              docRef,
                            ),
                            builder: (context, snapshot) {
                              final imageUrl = snapshot.data;
                              return GestureDetector(
                                onTap: imageUrl == null
                                    ? null
                                    : () => _viewDocumentImage(docRef),
                                child: ClipRRect(
                                  borderRadius: BorderRadius.circular(8),
                                  child: Container(
                                    width: 92,
                                    height: 92,
                                    color: Colors.grey.shade200,
                                    child: imageUrl == null
                                        ? const Center(
                                            child: SizedBox(
                                              width: 20,
                                              height: 20,
                                              child:
                                                  CircularProgressIndicator(
                                                strokeWidth: 2,
                                              ),
                                            ),
                                          )
                                        : Image.network(
                                            imageUrl,
                                            fit: BoxFit.cover,
                                            errorBuilder:
                                                (context, error, stackTrace) {
                                                  return const Center(
                                                    child: Icon(
                                                      Icons.broken_image_rounded,
                                                      color: Colors.grey,
                                                    ),
                                                  );
                                                },
                                          ),
                                  ),
                                ),
                              );
                            },
                          );
                        }).toList(),
                      ),
                    ],
                  ),
                const SizedBox(height: 12),
                Row(
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: [
                    OutlinedButton.icon(
                      onPressed: () => _editEntry(entry),
                      icon: const Icon(Icons.edit_rounded),
                      label: const Text('Edit entry'),
                    ),
                  ],
                ),
              ],
            ),
          );
        },
      ),
    );
  }
}

class _AnnouncementsTab extends StatelessWidget {
  const _AnnouncementsTab({required this.service});

  final SupabaseService service;

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<List<Announcement>>(
      future: service.fetchAnnouncements(),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Center(child: CircularProgressIndicator());
        }

        if (snapshot.hasError) {
          return const _ErrorState(
            message:
                'Could not load announcements. Verify your announcements table.',
          );
        }

        final items = snapshot.data ?? const [];
        if (items.isEmpty) {
          return const _EmptyState(
            title: 'No announcements yet',
            subtitle: 'Admin updates will appear here when posted.',
          );
        }

        return ListView.separated(
          padding: const EdgeInsets.all(16),
          itemCount: items.length,
          separatorBuilder: (_, index) => const SizedBox(height: 12),
          itemBuilder: (context, index) {
            final announcement = items[index];
            return Card(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      announcement.title,
                      style: Theme.of(context).textTheme.titleLarge,
                    ),
                    const SizedBox(height: 8),
                    Text(
                      _formatDate(announcement.createdAt),
                      style: Theme.of(context).textTheme.bodySmall,
                    ),
                    const SizedBox(height: 12),
                    Text(announcement.body),
                  ],
                ),
              ),
            );
          },
        );
      },
    );
  }
}

class _ProfileTab extends StatelessWidget {
  const _ProfileTab({
    required this.email,
    required this.isGuest,
    required this.onSignOut,
  });

  final String email;
  final bool isGuest;
  final VoidCallback onSignOut;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(20),
      child: Column(
        children: [
          Container(
            width: 92,
            height: 92,
            decoration: const BoxDecoration(
              shape: BoxShape.circle,
              color: AppColors.ateneoBlueMain,
            ),
            child: const Icon(Icons.person, color: Colors.white, size: 54),
          ),
          const SizedBox(height: 14),
          Text(
            email,
            textAlign: TextAlign.center,
            style: Theme.of(context).textTheme.titleMedium,
          ),
          const SizedBox(height: 10),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            decoration: BoxDecoration(
              color: AppColors.ateneoYellow2,
              borderRadius: BorderRadius.circular(999),
            ),
            child: Text(
              isGuest ? 'Role: Guest (Viewer)' : 'Role: Student Applicant',
              style: const TextStyle(fontWeight: FontWeight.w700),
            ),
          ),
          const Spacer(),
          ElevatedButton.icon(
            onPressed: onSignOut,
            icon: const Icon(Icons.logout_rounded),
            label: Text(isGuest ? 'Back to Login' : 'Sign Out'),
          ),
          const SizedBox(height: 10),
        ],
      ),
    );
  }
}

class _EmptyState extends StatelessWidget {
  const _EmptyState({required this.title, required this.subtitle});

  final String title;
  final String subtitle;

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(28),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(
              Icons.inbox_rounded,
              size: 52,
              color: AppColors.ateneoBlueMain,
            ),
            const SizedBox(height: 12),
            Text(
              title,
              style: Theme.of(context).textTheme.titleLarge,
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 8),
            Text(
              subtitle,
              style: Theme.of(context).textTheme.bodyMedium,
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );
  }
}

class _ErrorState extends StatelessWidget {
  const _ErrorState({required this.message});

  final String message;

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Text(
          message,
          textAlign: TextAlign.center,
          style: Theme.of(context).textTheme.bodyLarge,
        ),
      ),
    );
  }
}

String _formatDate(DateTime? dateTime) {
  if (dateTime == null) {
    return 'Not set';
  }

  const monthNames = [
    'Jan',
    'Feb',
    'Mar',
    'Apr',
    'May',
    'Jun',
    'Jul',
    'Aug',
    'Sep',
    'Oct',
    'Nov',
    'Dec',
  ];

  final month = monthNames[dateTime.month - 1];
  return '$month ${dateTime.day}, ${dateTime.year}';
}
