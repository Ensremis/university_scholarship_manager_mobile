import 'dart:convert';

class ScholarshipApplication {
  ScholarshipApplication({
    required this.id,
    required this.scholarshipId,
    required this.scholarshipTitle,
    required this.status,
    required this.submittedAt,
    required this.notes,
    required this.documentRefs,
  });

  final String id;
  final String scholarshipId;
  final String scholarshipTitle;
  final String status;
  final DateTime? submittedAt;
  final String notes;
  final List<String> documentRefs;

  String? get primaryDocumentRef =>
      documentRefs.isEmpty ? null : documentRefs.first;

  factory ScholarshipApplication.fromMap(Map<String, dynamic> map) {
    final scholarshipMap =
        (map['scholarship'] as Map<String, dynamic>?) ?? <String, dynamic>{};

    return ScholarshipApplication(
      id: map['id'].toString(),
      scholarshipId: map['scholarship_id'].toString(),
      scholarshipTitle: (scholarshipMap['title'] ?? 'Scholarship').toString(),
      status: (map['status'] ?? 'submitted').toString(),
      submittedAt: map['submitted_at'] != null
          ? DateTime.tryParse(map['submitted_at'].toString())
          : null,
      notes: (map['notes'] ?? '').toString(),
      documentRefs: _parseDocumentRefs(map['document_url']),
    );
  }

  static List<String> _parseDocumentRefs(dynamic rawValue) {
    if (rawValue == null) {
      return const [];
    }

    final rawString = rawValue.toString().trim();
    if (rawString.isEmpty) {
      return const [];
    }

    // New format: JSON array in document_url text column.
    if (rawString.startsWith('[')) {
      try {
        final decoded = jsonDecode(rawString);
        if (decoded is List) {
          return decoded
              .whereType<dynamic>()
              .map((item) => item.toString().trim())
              .where((item) => item.isNotEmpty)
              .toList();
        }
      } catch (_) {
        // Fall back to legacy single-value parsing below.
      }
    }

    // Legacy format: single URL/path string.
    return [rawString];
  }
}
