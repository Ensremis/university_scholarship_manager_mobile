class Scholarship {
  Scholarship({
    required this.id,
    required this.title,
    required this.description,
    required this.deadline,
    required this.requirements,
    required this.isOpen,
  });

  final String id;
  final String title;
  final String description;
  final DateTime? deadline;
  final List<String> requirements;
  final bool isOpen;

  factory Scholarship.fromMap(Map<String, dynamic> map) {
    return Scholarship(
      id: map['id'].toString(),
      title: (map['title'] ?? '').toString(),
      description: (map['description'] ?? '').toString(),
      deadline: map['deadline'] != null
          ? DateTime.tryParse(map['deadline'].toString())
          : null,
      requirements: ((map['requirements'] as List?) ?? const [])
          .map((item) => item.toString())
          .toList(),
      isOpen: map['is_open'] == true,
    );
  }
}
