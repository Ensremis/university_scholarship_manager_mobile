import 'scholarship_application.dart';

class EditableApplicationEntry {
  EditableApplicationEntry({
    required this.application,
    this.isExpanded = false,
  });

  final ScholarshipApplication application;
  final bool isExpanded;

  EditableApplicationEntry copyWith({
    ScholarshipApplication? application,
    bool? isExpanded,
  }) {
    return EditableApplicationEntry(
      application: application ?? this.application,
      isExpanded: isExpanded ?? this.isExpanded,
    );
  }

  factory EditableApplicationEntry.fromApplication(
    ScholarshipApplication application,
  ) {
    return EditableApplicationEntry(application: application);
  }
}
