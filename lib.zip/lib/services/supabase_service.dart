import 'dart:convert';
import 'dart:typed_data';

import 'package:supabase_flutter/supabase_flutter.dart';

import '../models/announcement.dart';
import '../models/scholarship.dart';
import '../models/scholarship_application.dart';

class SupabaseService {
  SupabaseService(this._client);

  static const String _requirementsBucket = 'requirements';

  final SupabaseClient _client;

  Future<AuthResponse> signInWithEmail({
    required String email,
    required String password,
  }) {
    return _client.auth.signInWithPassword(email: email, password: password);
  }

  Future<AuthResponse> signUpWithEmail({
    required String email,
    required String password,
  }) {
    return _client.auth.signUp(email: email, password: password);
  }

  Future<AuthResponse> signInWithGoogleTokens({
    required String idToken,
    String? accessToken,
  }) {
    return _client.auth.signInWithIdToken(
      provider: OAuthProvider.google,
      idToken: idToken,
      accessToken: accessToken,
    );
  }

  Future<void> signOut() => _client.auth.signOut();

  User? get currentUser => _client.auth.currentUser;

  Future<List<Scholarship>> fetchScholarships() async {
    final response = await _client
        .from('scholarships')
        .select('id, title, description, deadline, requirements, is_open')
        .order('deadline', ascending: true);

    return (response as List<dynamic>)
        .map((row) => Scholarship.fromMap(row as Map<String, dynamic>))
        .toList();
  }

  Future<List<ScholarshipApplication>> fetchApplicationsForUser(
    String userId,
  ) async {
    final response = await _client
        .from('applications')
        .select(
          'id, scholarship_id, status, submitted_at, notes, document_url, scholarship:scholarship_id(title)',
        )
        .eq('user_id', userId)
        .order('submitted_at', ascending: false);

    return (response as List<dynamic>)
        .map(
          (row) => ScholarshipApplication.fromMap(row as Map<String, dynamic>),
        )
        .toList();
  }

  Future<void> submitApplication({
    required String userId,
    required String scholarshipId,
    required String notes,
    List<String> documentRefs = const [],
  }) {
    return _client.from('applications').insert({
      'user_id': userId,
      'scholarship_id': scholarshipId,
      'status': 'submitted',
      'notes': notes,
      'document_url': _encodeDocumentRefs(documentRefs),
      'submitted_at': DateTime.now().toUtc().toIso8601String(),
    });
  }

  Future<bool> hasSubmittedApplication({
    required String userId,
    required String scholarshipId,
  }) async {
    final response = await _client
        .from('applications')
        .select('id')
        .eq('user_id', userId)
        .eq('scholarship_id', scholarshipId)
        .limit(1);

    final rows = response as List<dynamic>;
    return rows.isNotEmpty;
  }

  Future<void> updateApplicationForUser({
    required String applicationId,
    required String userId,
    required String notes,
    List<String>? documentRefs,
  }) async {
    final payload = <String, dynamic>{
      'notes': notes,
      'updated_at': DateTime.now().toUtc().toIso8601String(),
    };

    if (documentRefs != null) {
      payload['document_url'] = _encodeDocumentRefs(documentRefs);
    }

    await _client
        .from('applications')
        .update(payload)
        .eq('id', applicationId)
        .eq('user_id', userId);
  }

  Future<String> uploadApplicationPhoto({
    required String userId,
    required String scholarshipId,
    required Uint8List fileBytes,
    required String fileName,
  }) async {
    final extension = _extensionFromFileName(fileName);
    final timestamp = DateTime.now().millisecondsSinceEpoch;
    final path = '$userId/$scholarshipId/$timestamp.$extension';

    await _client.storage.from(_requirementsBucket).uploadBinary(
      path,
      fileBytes,
      fileOptions: FileOptions(
        upsert: false,
        contentType: _contentTypeForExtension(extension),
      ),
    );

    return path;
  }

  Future<String> buildDocumentAccessUrl(String documentRef) async {
    if (_isExternalHttpUrl(documentRef)) {
      return documentRef;
    }

    final normalized = _normalizeDocumentPath(documentRef);
    try {
      return await _client.storage.from(_requirementsBucket).createSignedUrl(
        normalized,
        60 * 60,
      );
    } on StorageException {
      // If signing fails (for example object missing), return a URL string so
      // the UI can handle display failure without throwing in async code.
      return _client.storage.from(_requirementsBucket).getPublicUrl(normalized);
    }
  }

  Future<List<Announcement>> fetchAnnouncements() async {
    final response = await _client
        .from('announcements')
        .select('id, title, body, created_at')
        .order('created_at', ascending: false)
        .limit(20);

    return (response as List<dynamic>)
        .map((row) => Announcement.fromMap(row as Map<String, dynamic>))
        .toList();
  }

  String _extensionFromFileName(String fileName) {
    final dotIndex = fileName.lastIndexOf('.');
    if (dotIndex == -1 || dotIndex == fileName.length - 1) {
      return 'jpg';
    }

    final rawExtension = fileName.substring(dotIndex + 1).toLowerCase();
    return rawExtension.replaceAll(RegExp(r'[^a-z0-9]'), '');
  }

  String _contentTypeForExtension(String extension) {
    switch (extension) {
      case 'png':
        return 'image/png';
      case 'webp':
        return 'image/webp';
      case 'heic':
        return 'image/heic';
      case 'heif':
        return 'image/heif';
      default:
        return 'image/jpeg';
    }
  }

  String? _encodeDocumentRefs(List<String> refs) {
    final filtered = refs
        .map((item) => item.trim())
        .where((item) => item.isNotEmpty)
        .toList();
    if (filtered.isEmpty) {
      return null;
    }
    return jsonEncode(filtered);
  }

  String _normalizeDocumentPath(String documentRef) {
    var path = documentRef.trim();
    if (path.startsWith('/')) {
      path = path.substring(1);
    }

    final publicMarker = '/storage/v1/object/public/$_requirementsBucket/';
    final signedMarker = '/storage/v1/object/sign/$_requirementsBucket/';

    final publicIndex = path.indexOf(publicMarker);
    if (publicIndex != -1) {
      return path.substring(publicIndex + publicMarker.length);
    }

    final signedIndex = path.indexOf(signedMarker);
    if (signedIndex != -1) {
      final tail = path.substring(signedIndex + signedMarker.length);
      final queryIndex = tail.indexOf('?');
      return queryIndex == -1 ? tail : tail.substring(0, queryIndex);
    }

    final bucketPrefix = '$_requirementsBucket/';
    if (path.startsWith(bucketPrefix)) {
      return path.substring(bucketPrefix.length);
    }

    return path;
  }

  bool _isExternalHttpUrl(String value) {
    final trimmed = value.trim();
    if (!trimmed.startsWith('http://') && !trimmed.startsWith('https://')) {
      return false;
    }

    // Supabase storage URLs should be normalized to object paths and signed.
    if (trimmed.contains('/storage/v1/object/public/$_requirementsBucket/')) {
      return false;
    }
    if (trimmed.contains('/storage/v1/object/sign/$_requirementsBucket/')) {
      return false;
    }

    return true;
  }
}
